import os
import re
from rank_bm25 import BM25Okapi

# Глобальные переменные для хранения базы знаний и поискового движка
knowledge_base = []
bm25 = None

def load_and_index_rules():
    """Считывает официальный файл rules.md и индексирует его для поиска."""
    global bm25, knowledge_base
    path = os.path.join("data", "rules.md")
    
    if not os.path.exists(path):
        print(f"[КРИТИЧЕСКАЯ ОШИБКА RAG]: Файл {path} не найден! Положите rules.md в папку data.")
        return
        
    with open(path, "r", encoding="utf-8") as f:
        content = f.read()
    
    # Регулярное выражение, которое находит любые пункты (например, "### 1.2", "Пункт 3.4", "4.2.")
    # Оно делит текст на отдельные смысловые блоки
    paragraphs = re.split(r'(?=###\s+\d+\.\d+|Пункт\s+\d+\.\d+|п\.\s+\d+\.\d+|\n\d+\.\d+)', content)
    
    knowledge_base = []
    for p in paragraphs:
        p_trimmed = p.strip()
        if not p_trimmed:
            continue
            
        # Автоматически вытаскиваем номер пункта (например, "3.4") из заголовка или текста блока
        match = re.search(r'(\d+\.\d+)', p_trimmed)
        rule_id = match.group(1) if match else "Общие правила"
        
        # Очищаем текст пункта от Markdown-разметки (символов #, * и т.д.) для чистоты промпта
        clean_text = re.sub(r'[#\*`_-]', ' ', p_trimmed)
        
        knowledge_base.append({
            "rule_id": rule_id, 
            "text": ' '.join(clean_text.split())
        })
        
    # Строим текстовый индекс для алгоритма BM25
    corpus = [doc["text"] for doc in knowledge_base]
    tokenized_corpus = [doc_text.lower().split() for doc_text in corpus]
    bm25 = BM25Okapi(tokenized_corpus)

# Автоматически запускаем индексацию официального файла при старте проекта
load_and_index_rules()

def search_rag(query: str):
    """Ищет в rules.md самый подходящий пункт по тексту запроса."""
    if not knowledge_base or bm25 is None:
        return "1.2", "База знаний правил пуста."
        
    # Ищем совпадения по словам
    tokenized_query = query.lower().split()
    best_doc_text = bm25.get_top_n(tokenized_query, [doc["text"] for doc in knowledge_base], n=1)[0]
    
    # Возвращаем ID найденного пункта и его полный текст
    for doc in knowledge_base:
        if doc["text"] == best_doc_text:
            return doc["rule_id"], doc["text"]
            
    return "1.2", best_doc_text