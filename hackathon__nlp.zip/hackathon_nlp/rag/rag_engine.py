import os
import re
from rank_bm25 import BM25Okapi

knowledge_base = []
bm25 = None

def load_and_index_rules():
    """Считывает официальный файл rules.md и индексирует его для поиска."""
    global bm25, knowledge_base
    path = os.path.join("data", "rules.md")
    
    if not os.path.exists(path):
        return
        
    with open(path, "r", encoding="utf-8") as f:
        content = f.read()
    
    # Нарезаем файл по пунктам (3., 4., 5. и т.д.)
    paragraphs = re.split(r'(?=\n\d+\.\s+|###\s+\d+)', content)
    
    knowledge_base = []
    for p in paragraphs:
        p_trimmed = p.strip()
        if not p_trimmed:
            continue
            
        match = re.search(r'(\d+)', p_trimmed)
        rule_id = match.group(1) if match else "Общие правила"
        
        clean_text = re.sub(r'[#\*`_-]', ' ', p_trimmed)
        knowledge_base.append({
            "rule_id": rule_id, 
            "text": ' '.join(clean_text.split())
        })
        
    if knowledge_base:
        corpus = [doc["text"] for doc in knowledge_base]
        tokenized_corpus = [doc_text.lower().split() for doc_text in corpus]
        bm25 = BM25Okapi(tokenized_corpus)

# Автоматический запуск при импорте модуля
load_and_index_rules()

def search_rag(query: str):
    """Ищет в rules.md самый подходящий пункт. Гарантированно возвращает СТРОКУ."""
    global knowledge_base, bm25
    
    # Жесткий предохранитель: если база пуста или не инициализирована
    if not knowledge_base or bm25 is None:
        return "3", "База знаний правил пуста или не найдена."
        
    tokenized_query = query.lower().split()
    if not tokenized_query:
        return "3", knowledge_base[0]["text"]
        
    # Находим лучший текст документа
    best_doc_text_list = bm25.get_top_n(tokenized_query, [doc["text"] for doc in knowledge_base], n=1)
    
    # Проверяем, что вернулся не пустой список
    if not best_doc_text_list:
        return "3", knowledge_base[0]["text"]
        
    best_doc_text = best_doc_text_list[0]
    
    for doc in knowledge_base:
        if doc["text"] == best_doc_text:
            return str(doc["rule_id"]), str(doc["text"])
            
    # Защитный фолбэк: если совпадение размыто, возвращаем первый элемент базы в виде строки
    return "3", str(knowledge_base[0]["text"])
