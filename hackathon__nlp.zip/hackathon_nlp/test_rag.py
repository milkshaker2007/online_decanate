import json
# Импортируем функции строго из вашей папки rag
from rag.rag_engine import search_rag
from rag.llm_model import run_llm_inference

def process_student_request(doc_name, raw_ocr_text, extracted_fields, student_question):
    """Главный конвейер, который объединяет ваши два файла."""
    
    # 1. Поиск правила по названию документа через ваш rag_engine
    rule_id, rule_text = search_rag(doc_name)
    print(f"[RAG ТЕСТ] Поисковик BM25 определил пункт правил: п. {rule_id}")
    
    # 2. Мгновенная проверка Сценария 2 (если CV/OCR-модуль передал "не найдено")
    if any(val == "не найдено" for val in extracted_fields.values()):
        missing_fields = [k for k, v in extracted_fields.items() if v == "не найдено"]
        return f"Не хватает {', '.join(missing_fields)}. Эти поля обязательны по п. {rule_id} Положения."
        
    # 3. Жесткая проверка Сценария 3 (Вопрос не по теме правил)
    important_words = ["проездной", "билет", "шаурма", "стипендия", "общежитие", "деньги"]
    if any(word in student_question.lower() for word in important_words) and not any(word in rule_text.lower() for word in important_words):
        return f"В документе и в Положении нет информации о {student_question}. Обратитесь в деканат."
        
    # 4. Локальный инференс нейросети из вашего llm_model
    print("[LLM ТЕСТ] Запуск локальной нейросети Qwen на CPU...")
    llm_output = run_llm_inference(doc_name, raw_ocr_text, extracted_fields, rule_id, rule_text, student_question)
    
    # 5. Проверка Сценария 3 со стороны самой LLM
    if "Сценарий 3" in llm_output or "нет информации" in llm_output:
        return f"В документе и в Положении нет информации о {student_question}. Обратитесь в деканат."
        
    # Сценарий 1 (Все проверки пройдены)
    return f"{doc_name} содержит все данные, которые требует п. {rule_id} Положения. Окончательное решение примет сотрудник деканата"


if __name__ == "__main__":
    print("\n" + "="*50)
    print(" ЗАПУСК ЛОКАЛЬНОГО ТЕСТА ВАШЕЙ ПАПКИ RAG ")
    print("="*50)

    # Имитируем живые данные из ocr_output.json (Сценарий 2 - не хватает полей в Справке)
    try:
        with open("ocr_output.json", "r", encoding="utf-8-sig") as f:
            ocr_report = json.load(f)
            
        print(f"Входной вопрос из JSON: '{ocr_report['student_question']}'")
        print(f"Тип документа: '{ocr_report['doc_name']}'")
        
        # Запускаем связку ваших файлов
        final_answer = process_student_request(
            doc_name=ocr_report["doc_name"],
            raw_ocr_text=ocr_report["raw_ocr_text"],
            extracted_fields=ocr_report["extracted_fields"],
            student_question=ocr_report["student_question"]
        )
        
        print("\n" + "-"*40)
        print("[РЕЗУЛЬТАТ ВАШЕГО МОДУЛЯ ДЛЯ СДАЧИ]:")
        print(final_answer)
        print("-"*40 + "\n")
        
    except FileNotFoundError:
        print("[ОШИБКА]: Положите файл ocr_output.json в корень рядом со скриптом.")
    except Exception as e:
        print(f"[ОШИБКА ТЕСТА]: {e}")
